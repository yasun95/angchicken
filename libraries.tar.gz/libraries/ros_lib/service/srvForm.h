#ifndef _ROS_SERVICE_srvForm_h
#define _ROS_SERVICE_srvForm_h
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace service
{

static const char SRVFORM[] = "service/srvForm";

  class srvFormRequest : public ros::Msg
  {
    public:
      typedef uint8_t _x_type;
      _x_type x;
      uint32_t y_length;
      typedef uint8_t _y_type;
      _y_type st_y;
      _y_type * y;

    srvFormRequest():
      x(0),
      y_length(0), y(NULL)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      *(outbuffer + offset + 0) = (this->x >> (8 * 0)) & 0xFF;
      offset += sizeof(this->x);
      *(outbuffer + offset + 0) = (this->y_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->y_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->y_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->y_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->y_length);
      for( uint32_t i = 0; i < y_length; i++){
      *(outbuffer + offset + 0) = (this->y[i] >> (8 * 0)) & 0xFF;
      offset += sizeof(this->y[i]);
      }
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      this->x =  ((uint8_t) (*(inbuffer + offset)));
      offset += sizeof(this->x);
      uint32_t y_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      y_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      y_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      y_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->y_length);
      if(y_lengthT > y_length)
        this->y = (uint8_t*)realloc(this->y, y_lengthT * sizeof(uint8_t));
      y_length = y_lengthT;
      for( uint32_t i = 0; i < y_length; i++){
      this->st_y =  ((uint8_t) (*(inbuffer + offset)));
      offset += sizeof(this->st_y);
        memcpy( &(this->y[i]), &(this->st_y), sizeof(uint8_t));
      }
     return offset;
    }

    const char * getType(){ return SRVFORM; };
    const char * getMD5(){ return "706dbd41e27bb8b63811a0b387900644"; };

  };

  class srvFormResponse : public ros::Msg
  {
    public:
      typedef uint8_t _result_type;
      _result_type result;
      uint32_t hex_result_length;
      typedef uint8_t _hex_result_type;
      _hex_result_type st_hex_result;
      _hex_result_type * hex_result;

    srvFormResponse():
      result(0),
      hex_result_length(0), hex_result(NULL)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      *(outbuffer + offset + 0) = (this->result >> (8 * 0)) & 0xFF;
      offset += sizeof(this->result);
      *(outbuffer + offset + 0) = (this->hex_result_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->hex_result_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->hex_result_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->hex_result_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->hex_result_length);
      for( uint32_t i = 0; i < hex_result_length; i++){
      *(outbuffer + offset + 0) = (this->hex_result[i] >> (8 * 0)) & 0xFF;
      offset += sizeof(this->hex_result[i]);
      }
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      this->result =  ((uint8_t) (*(inbuffer + offset)));
      offset += sizeof(this->result);
      uint32_t hex_result_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      hex_result_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      hex_result_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      hex_result_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->hex_result_length);
      if(hex_result_lengthT > hex_result_length)
        this->hex_result = (uint8_t*)realloc(this->hex_result, hex_result_lengthT * sizeof(uint8_t));
      hex_result_length = hex_result_lengthT;
      for( uint32_t i = 0; i < hex_result_length; i++){
      this->st_hex_result =  ((uint8_t) (*(inbuffer + offset)));
      offset += sizeof(this->st_hex_result);
        memcpy( &(this->hex_result[i]), &(this->st_hex_result), sizeof(uint8_t));
      }
     return offset;
    }

    const char * getType(){ return SRVFORM; };
    const char * getMD5(){ return "b6a05fd63c99d558892305a3f4fe720b"; };

  };

  class srvForm {
    public:
    typedef srvFormRequest Request;
    typedef srvFormResponse Response;
  };

}
#endif
