#include "ros/ros.h"
#include "service/srvForm.h"
#include <cstdlib>

int main(int argc, char ** argv){
    ros::init(argc, argv, "client");

    ros::NodeHandle nh;
    ros::ServiceClient client = nh.serviceClient<service::srvForm>("service");

    service::srvForm srv;

    /*
    for (int i = 0; i < 11; i++){
        srv.request.x = atoi(argv[i]);
        ROS_INFO("%d", i);
    }
    */
    for(int i = 0; i < 11; i++){
        srv.request.x = i;
        //srv.request.y[] = ;
    
        //srv.request.x = 3;
        //srv.request.y = 2;

        if(client.call(srv)){
            ROS_INFO("request - %d", srv.request.x);
            //ROS_INFO("request of hex number - %x", srv.request.y;
            ROS_INFO("response - %d", srv.response.result);
            //ROS_INFO("response of hex number - %x", srv.response.hex_result);
         }
    
        else{
            ROS_INFO("NO INFO");
            return 1;
        }
    }
    return 0;
}