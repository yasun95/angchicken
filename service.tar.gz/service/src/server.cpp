#include "ros/ros.h"
#include "service/srvForm.h"

using service::srvForm;

bool srvInfo(service::srvForm::Request &req, service::srvForm::Response &res){
    /*
    unsigned int header1 = 255;
    unsigned int header2 = 254;
	unsigned int id = 0;
	unsigned int data_size = 7;
	unsigned int mode = 1;
	unsigned int direction = 0;
	unsigned int position1 = 0;
	unsigned int position2 = 60;
	unsigned int velocity1 = 0;
	unsigned int velocity2 = 50;
    

    srvForm::Response header1, header2, id, data_size, ~check_sum, mode, direction, position1, position2, velocity1, velocity2;

    srvForm::check_sum = header1 + header2 + id + data_size + mode + direction + position1 + position2;

    const unsigned int buffer_size = 11;
    unsigned int data_array[buffer_size] = {header1, header2, id, data_size, ~check_sum, mode, direction, position1, position2, velocity1, velocity2};
    ex[buffer_size]  = {header1, header2, id, data_size, ~check_sum, mode, direction, position1, position2, velocity1, velocity2};

    res.xresult = data_array[req.x];
    res.yresult = hex[req.y];

    ROS_INFO("request number is %d", req.x);
    ROS_INFO("request number of hex is %x", req.y);
    ROS_INFO("result number is %d", res.xresult);
    //ROS_INFO("result number of hex is %x", res.hex_result);

    return true;
    */
}

int main(int argc, char **argv){
    ros::init(argc, argv, "server");
    ros::NodeHandle nh;

    ros::ServiceServer service = nh.advertiseService("service", srvInfo);
    ROS_INFO("Ready to response.");

    ros::spin();

    return 0;
}